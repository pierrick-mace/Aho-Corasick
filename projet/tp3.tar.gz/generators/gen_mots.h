#ifndef __GEN_MOTS_H__
#define __GEN_MOTS_H__

void generate_text(char string[], int len, int alphabet_size);
char generate_random_character(int alphabet_size);

#endif
